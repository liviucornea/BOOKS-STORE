package com.scotiabank.voice.bio.data.cams;

/**
 * Created by LCornea on 5/11/2017.
 */
public class ResponseToPreregisterDTO  extends CamsResponseDTO  {
    public PreregisterResponseUserDTO appUser;

    public ResponseToPreregisterDTO(){}

}
