package com.scotiabank.voice.bio.data;

import java.io.Serializable;

/**
 * Created by LiviuCornea on 04/19/2017.
 */
public class BaseData implements Serializable {
}
