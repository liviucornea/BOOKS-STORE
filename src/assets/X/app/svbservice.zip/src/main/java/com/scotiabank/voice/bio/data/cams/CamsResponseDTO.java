package com.scotiabank.voice.bio.data.cams;

import java.io.Serializable;

/**
 * Created by LCornea on 5/8/2017.
 */
public class CamsResponseDTO implements Serializable {
    public StatusDTO status;

}
