package com.scotiabank.voice.bio;

import org.springframework.context.annotation.Configuration;

/**
 * Created by LiviuCornea on 04/19/2017.
 */
@Configuration
public class ConfigClass {
}
