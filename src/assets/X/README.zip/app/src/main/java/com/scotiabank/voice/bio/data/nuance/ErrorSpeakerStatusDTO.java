package com.scotiabank.voice.bio.data.nuance;

/**
 * Created by LCornea on 5/24/2017.
 */
public class ErrorSpeakerStatusDTO {
    public NuanceErrorSpeaker errorDetails;

public ErrorSpeakerStatusDTO(){}

}


