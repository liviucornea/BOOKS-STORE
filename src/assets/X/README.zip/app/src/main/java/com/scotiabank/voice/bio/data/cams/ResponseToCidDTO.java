package com.scotiabank.voice.bio.data.cams;

import java.util.ArrayList;

/**
 * Created by LCornea on 5/8/2017.
 */
public class ResponseToCidDTO extends CamsResponseDTO {

    public ArrayList<AppUserDTO> appUsers;

    public ResponseToCidDTO() {
    }

}


