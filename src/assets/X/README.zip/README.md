# Project for Voice Biometrics

## It is a web service bridge between AS400, CMS and Nuance

